#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "kernels_util_all_deps" for configuration "Release"
set_property(TARGET kernels_util_all_deps APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(kernels_util_all_deps PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libkernels_util_all_deps.a"
  )

list(APPEND _cmake_import_check_targets kernels_util_all_deps )
list(APPEND _cmake_import_check_files_for_kernels_util_all_deps "${_IMPORT_PREFIX}/lib/libkernels_util_all_deps.a" )

# Import target "portable_kernels" for configuration "Release"
set_property(TARGET portable_kernels APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(portable_kernels PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libportable_kernels.a"
  )

list(APPEND _cmake_import_check_targets portable_kernels )
list(APPEND _cmake_import_check_files_for_portable_kernels "${_IMPORT_PREFIX}/lib/libportable_kernels.a" )

# Import target "portable_ops_lib" for configuration "Release"
set_property(TARGET portable_ops_lib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(portable_ops_lib PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libportable_ops_lib.a"
  )

list(APPEND _cmake_import_check_targets portable_ops_lib )
list(APPEND _cmake_import_check_files_for_portable_ops_lib "${_IMPORT_PREFIX}/lib/libportable_ops_lib.a" )

# Import target "executorch" for configuration "Release"
set_property(TARGET executorch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(executorch PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexecutorch.a"
  )

list(APPEND _cmake_import_check_targets executorch )
list(APPEND _cmake_import_check_files_for_executorch "${_IMPORT_PREFIX}/lib/libexecutorch.a" )

# Import target "executorch_core" for configuration "Release"
set_property(TARGET executorch_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(executorch_core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexecutorch_core.a"
  )

list(APPEND _cmake_import_check_targets executorch_core )
list(APPEND _cmake_import_check_files_for_executorch_core "${_IMPORT_PREFIX}/lib/libexecutorch_core.a" )

# Import target "executorch_delegate_ethos_u" for configuration "Release"
set_property(TARGET executorch_delegate_ethos_u APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(executorch_delegate_ethos_u PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexecutorch_delegate_ethos_u.a"
  )

list(APPEND _cmake_import_check_targets executorch_delegate_ethos_u )
list(APPEND _cmake_import_check_files_for_executorch_delegate_ethos_u "${_IMPORT_PREFIX}/lib/libexecutorch_delegate_ethos_u.a" )

# Import target "cortex_m_kernels" for configuration "Release"
set_property(TARGET cortex_m_kernels APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(cortex_m_kernels PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libcortex_m_kernels.a"
  )

list(APPEND _cmake_import_check_targets cortex_m_kernels )
list(APPEND _cmake_import_check_files_for_cortex_m_kernels "${_IMPORT_PREFIX}/lib/libcortex_m_kernels.a" )

# Import target "cortex_m_ops_lib" for configuration "Release"
set_property(TARGET cortex_m_ops_lib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(cortex_m_ops_lib PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libcortex_m_ops_lib.a"
  )

list(APPEND _cmake_import_check_targets cortex_m_ops_lib )
list(APPEND _cmake_import_check_files_for_cortex_m_ops_lib "${_IMPORT_PREFIX}/lib/libcortex_m_ops_lib.a" )

# Import target "extension_runner_util" for configuration "Release"
set_property(TARGET extension_runner_util APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(extension_runner_util PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/home/developer/executorch/arm_test/cmake-out/lib/libextension_runner_util.a"
  )

list(APPEND _cmake_import_check_targets extension_runner_util )
list(APPEND _cmake_import_check_files_for_extension_runner_util "/home/developer/executorch/arm_test/cmake-out/lib/libextension_runner_util.a" )

# Import target "quantized_kernels" for configuration "Release"
set_property(TARGET quantized_kernels APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(quantized_kernels PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libquantized_kernels.a"
  )

list(APPEND _cmake_import_check_targets quantized_kernels )
list(APPEND _cmake_import_check_files_for_quantized_kernels "${_IMPORT_PREFIX}/lib/libquantized_kernels.a" )

# Import target "quantized_ops_lib" for configuration "Release"
set_property(TARGET quantized_ops_lib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(quantized_ops_lib PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libquantized_ops_lib.a"
  )

list(APPEND _cmake_import_check_targets quantized_ops_lib )
list(APPEND _cmake_import_check_files_for_quantized_ops_lib "${_IMPORT_PREFIX}/lib/libquantized_ops_lib.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
